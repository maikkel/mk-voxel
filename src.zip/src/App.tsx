import EditorApp from "./editor/EditorApp";

export default function App() {
  return <EditorApp />;
}
