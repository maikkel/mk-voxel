import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import { MantineProvider, createTheme } from "@mantine/core";
import "@mantine/core/styles.css"; // ✅ Correct place
import "./styles.scss";

const theme = createTheme({
  primaryColor: "yellow",
});
ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <MantineProvider theme={theme} defaultColorScheme="dark" withCssVariables>
      <App />
    </MantineProvider>
  </React.StrictMode>,
);
