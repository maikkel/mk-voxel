import { Box, useMantineTheme } from "@mantine/core";
import { useEffect, useRef } from "react";
import { initEditorScene } from "./initEditorScene";
import { Panel, PanelGroup, PanelResizeHandle } from "react-resizable-panels";
import View from "./components/View";
import { SpriteEdit } from "./components/SpriteEdit";

export default function EditorApp() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const theme = useMantineTheme();
  console.log("theme", theme);

  useEffect(() => {
    if (canvasRef.current) {
      initEditorScene(canvasRef.current);
    }
  }, []);

  return (
    <div style={{ height: "100vh" }}>
      <PanelGroup direction="vertical" style={{ height: "100%" }}>
        <Panel defaultSize={50}>
          <PanelGroup direction="horizontal" style={{ height: "100%" }}>
            <Panel defaultSize={50}>
              <Box
                h="100%"
                w="100%"
                style={{
                  overflow: "auto",
                  padding: "var(--mantine-spacing-sm)",
                }}
              >
                <SpriteEdit />
              </Box>
            </Panel>
            <PanelResizeHandle>
              <div className="resize-handle-bar horizontal" />
            </PanelResizeHandle>
            <Panel defaultSize={50}>
              <Box h="100%" w="100%" style={{ overflow: "auto" }}>
                <View />
              </Box>
            </Panel>
          </PanelGroup>
        </Panel>
        <PanelResizeHandle>
          <div className="resize-handle-bar vertical" />
        </PanelResizeHandle>
        <Panel defaultSize={50}>
          <PanelGroup direction="horizontal" style={{ height: "100%" }}>
            <Panel defaultSize={50}>
              <Box
                h="100%"
                w="100%"
                style={{
                  overflow: "auto",
                  padding: "var(--mantine-spacing-sm)",
                }}
              >
                Bottom Left
              </Box>
            </Panel>
            <PanelResizeHandle>
              <div className="resize-handle-bar horizontal" />
            </PanelResizeHandle>
            <Panel defaultSize={50}>
              <Box
                h="100%"
                w="100%"
                style={{
                  overflow: "auto",
                  padding: "var(--mantine-spacing-sm)",
                }}
              >
                Bottom Right
              </Box>
            </Panel>
          </PanelGroup>
        </Panel>
      </PanelGroup>
    </div>
  );
}
