import { create } from 'zustand';
import { SpriteData } from '../../engine/types';
import { createEmptySprite } from '../../engine/core/utils/sprite';

const initialSpriteData = createEmptySprite(7, 7, 7);

interface SpriteStore {
  spriteData: SpriteData | null;
  setSpriteData: (data: SpriteData) => void;

  currentAnimationName: string;
  setCurrentAnimationName: (name: string) => void;

  currentFrameIndex: number;
  setCurrentFrameIndex: (index: number) => void;
}

export const useSpriteStore = create<SpriteStore>((set, get) => ({
  spriteData: initialSpriteData,
  setSpriteData: (data: SpriteData) => {
    console.log('set', data);
    set({ spriteData: data });
  },
  currentAnimationName: initialSpriteData.animations[0].name,
  setCurrentAnimationName: (name) => set({ currentAnimationName: name }),
  currentFrameIndex: 0,
  setCurrentFrameIndex: (index) => set({ currentFrameIndex: index }),
}));
