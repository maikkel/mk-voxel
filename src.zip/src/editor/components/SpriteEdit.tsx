import { useSpriteStore } from '../hooks/useSpriteStore';
import { Group, NumberInput, Stack, Title, Text } from '@mantine/core';
import { resizeSpriteDimensions } from '../../engine/core/utils/sprite';

export function SpriteEdit() {
  const spriteData = useSpriteStore((state) => state.spriteData);
  const setSpriteData = useSpriteStore((state) => state.setSpriteData);
  const updateDimensionsStore = useSpriteStore((s) => s.updateDimensions);

  if (!spriteData) return <div>No sprite loaded</div>;

  const updateDimensions = (key: 'x' | 'y' | 'z', value: string | number) => {
    if (value === '' || typeof value === 'string' || !spriteData) return;

    const newDims = {
      ...spriteData.dimensions,
      [key]: value as number,
    };

    setSpriteData(resizeSpriteDimensions(spriteData, newDims));
  };

  const updateFrameTime = (value: string | number) => {
    if (value === '') return;
    setSpriteData({
      ...spriteData,
      frameTime: typeof value === 'number' ? value : 0,
    });
  };

  return (
    <Stack>
      <Title order={3}>Sprite Properties</Title>
      <Text size="sm" fw={500}>
        Dimensions (x, y, z)
      </Text>
      <Group grow gap="sm">
        <NumberInput
          label="X"
          value={spriteData.dimensions.x}
          onChange={(value) => updateDimensions('x', value)}
          min={1}
        />
        <NumberInput
          label="Y"
          value={spriteData.dimensions.y}
          onChange={(value) => updateDimensions('y', value)}
          min={1}
        />
        <NumberInput
          label="Z"
          value={spriteData.dimensions.z}
          onChange={(value) => updateDimensions('z', value)}
          min={1}
        />
      </Group>
      <NumberInput
        label="Global Frame Time (ms), override in Animation or Frame"
        value={spriteData.frameTime}
        onChange={updateFrameTime}
        min={1}
      />
    </Stack>
  );
}
