import { ColorKey } from '../../types';

export function createEmptyFrame(x: number, y: number, z: number): (ColorKey | null)[][][] {
  return Array(z)
    .fill(null)
    .map(() =>
      Array(y)
        .fill(null)
        .map(() => Array(x).fill(null))
    );
}
