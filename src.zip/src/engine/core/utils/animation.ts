import { VoxelAnimation } from '../../types';
import { createEmptyFrame } from './frame';

export function createEmptyAnimation(
  x: number,
  y: number,
  z: number,
  name: string
): VoxelAnimation {
  return {
    name: name,
    frameTime: 100,
    frames: [{ colors: createEmptyFrame(x, y, z) }],
  };
}
