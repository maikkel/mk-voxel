import { SpriteData } from '../../types';
import { createEmptyFrame } from './frame';
import { createEmptyAnimation } from './animation';

function resizeFrameColors(
  oldColors: (string | null)[][][],
  newX: number,
  newY: number,
  newZ: number
): (string | null)[][][] {
  const resized: (string | null)[][][] = [];
  for (let z = 0; z < newZ; z++) {
    const layer: (string | null)[][] = [];
    for (let y = 0; y < newY; y++) {
      const row: (string | null)[] = [];
      for (let x = 0; x < newX; x++) {
        row.push(oldColors[z]?.[y]?.[x] ?? null);
      }
      layer.push(row);
    }
    resized.push(layer);
  }
  return resized;
}

export function resizeSpriteDimensions(
  spriteData: SpriteData,
  newDims: { x: number; y: number; z: number }
): SpriteData {
  return {
    ...spriteData,
    dimensions: newDims,
    animations: spriteData.animations.map((animation) => ({
      ...animation,
      frames: animation.frames.map((frame) => ({
        ...frame,
        colors: resizeFrameColors(frame.colors, newDims.x, newDims.y, newDims.z),
      })),
    })),
  };
}

export function createEmptySprite(
  x: number,
  y: number,
  z: number,
  defaultAnimationName = 'default'
): SpriteData {
  return {
    palette: {
      r: { color: '#ff0000' },
      g: { color: '#00ff00' },
      b: { color: '#0000ff' },
    },
    dimensions: { x, y, z },
    frameTime: 100,
    animations: [createEmptyAnimation(x, y, z, defaultAnimationName)],
  };
}
