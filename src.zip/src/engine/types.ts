export type ColorKey = string; // e.g. "r", "g", "b"

export interface Palette {
  [key: ColorKey]: {
    color: string; // e.g. "#00ffcc"
    glow?: boolean; // add other props like metallic, emissive, etc.
  };
}

export interface VoxelAnimation {
  name: string; // Name of the animation (e.g., "firing", "idle")
  frames: VoxelFrame[]; // Array of frames for this animation
  frameTime?: number; // Time per frame.ts (in ms)
}

export interface VoxelFrame {
  time?: number;
  colors: (ColorKey | null)[][][];
}

export interface SpriteData {
  palette: Palette;
  dimensions: { x: number; y: number; z: number };
  frameTime: number;
  animations: VoxelAnimation[];
}
